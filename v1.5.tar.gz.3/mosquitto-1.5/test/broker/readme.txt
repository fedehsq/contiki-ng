----- Broker Tests -----

This folder contains a number of tests to exercise the functionality of the
broker. Feel free to add more.

Numbering is as follows:

01: Connection tests
02: Subscribe/unsubscribe tests
03: Publish tests
04: Retained message tests
05: Clean session tests
06: Bridge tests
07: Will tests
