#!/bin/ash

set -e
exec "$@"

